package com.nice.coding.assignment.departmentservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nice.coding.assignment.departmentservice.entity.Department;
import com.nice.coding.assignment.departmentservice.service.DepartmentService;


@RestController
@RequestMapping("/departments")
public class DepartmentController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
    private DepartmentService departmentService;

    @PostMapping("/")
    public Department saveDepartment(@RequestBody Department department) {
//        logger.info("Inside saveDepartment method of DepartmentController");
        return  departmentService.saveDepartment(department);
    }

    @GetMapping("/{id}")
    public Department findDepartmentById(@PathVariable("id") Long id) {
//        logger.info("Inside findDepartmentById method of DepartmentController");
    	System.out.println("----------id----------"+id);
        return departmentService.findDepartmentById(id);
    }
    
    @GetMapping("/")
    public List<Department> reteriveAllDepartmentValues() {
//        logger.info("Inside reteriveAllDepartmentValues method of DepartmentController");
        return departmentService.reteriveAllDepartmentValues();
    }


	
}
