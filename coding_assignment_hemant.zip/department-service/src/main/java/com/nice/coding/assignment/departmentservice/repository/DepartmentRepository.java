package com.nice.coding.assignment.departmentservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nice.coding.assignment.departmentservice.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long>{
	Department findByid(Long id);
}
