package com.nice.coding.assignment.departmentservice.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nice.coding.assignment.departmentservice.entity.Department;
import com.nice.coding.assignment.departmentservice.repository.DepartmentRepository;

@Service
public class DepartmentService {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
    private DepartmentRepository departmentRepository;

    public Department saveDepartment(Department department) {
//        logger.info("Inside saveDepartment of DepartmentService");
        return departmentRepository.save(department);
    }

    public Department findDepartmentById(Long id) {
//        logger.info("Inside findDepartmentById of DepartmentService");
        return departmentRepository.findByid(id);
    }
    
    public List<Department> reteriveAllDepartmentValues() {
//      logger.info("Inside reteriveAllDepartmentValues of DepartmentService");
      return departmentRepository.findAll();
  }
}
