package com.nice.coding.assignment.employeeservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nice.coding.assignment.employeeservice.entity.Employee;
import com.nice.coding.assignment.employeeservice.proxy.Department;
import com.nice.coding.assignment.employeeservice.proxy.DepartmentServiceProxy;
import com.nice.coding.assignment.employeeservice.proxy.ResponseVO;
import com.nice.coding.assignment.employeeservice.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository 	employeeRepository;
	
	@Autowired
	DepartmentServiceProxy departmentServiceProxy;
	
	public Employee saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepository.save(employee);
	}

	public List<Employee> reteriveAllEmployeeValues() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}
	
	public ResponseVO findByEmployeeId(Long employeeId) {
		ResponseVO responseVO=new ResponseVO();
		Employee employee=employeeRepository.findByemployeeId(employeeId);
		Department department =departmentServiceProxy.findDepartmentById(employee.getDepartmentId());
		responseVO.setEmployee(employee);
		responseVO.setDepartment(department);
		return responseVO ;
	}
	
	public ResponseVO findEmployeeByDepartmentId(Long departmentId) {
		ResponseVO responseVO=new ResponseVO();
		
		Department department =departmentServiceProxy.findDepartmentById(departmentId);
     	responseVO.setLstEmployee(employeeRepository.findBydepartmentId(department.getDhead()));
		responseVO.setDepartment(department);
		return responseVO ;
	}

}
