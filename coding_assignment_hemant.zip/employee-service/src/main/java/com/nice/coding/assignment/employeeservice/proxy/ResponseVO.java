package com.nice.coding.assignment.employeeservice.proxy;

import java.util.List;

import com.nice.coding.assignment.employeeservice.entity.Employee;

public class ResponseVO {
	Department department;
	Employee employee;
	List<Employee> lstEmployee;
	
	public List<Employee> getLstEmployee() {
		return lstEmployee;
	}
	public void setLstEmployee(List<Employee> lstEmployee) {
		this.lstEmployee = lstEmployee;
	}
	public ResponseVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ResponseVO(Department department, Employee employee) {
		super();
		this.department = department;
		this.employee = employee;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}
