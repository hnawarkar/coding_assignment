package com.nice.coding.assignment.employeeservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nice.coding.assignment.employeeservice.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long>{

	Employee findByemployeeId(Long employeeId);
	List<Employee> findBydepartmentId(Long departmentId);

}
