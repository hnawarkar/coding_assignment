package com.nice.coding.assignment.employeeservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.nice.coding.assignment.employeeservice.entity.Employee;
import com.nice.coding.assignment.employeeservice.proxy.ResponseVO;
import com.nice.coding.assignment.employeeservice.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	EmployeeService employeeService;
	
	@PostMapping("/")
	private Employee saveEmployee(@RequestBody Employee employee) {
		// TODO Auto-generated method stub
		logger.info("Inside saveEmployee method of EmployeeController");
		return employeeService.saveEmployee(employee);
	}

	
	@GetMapping("/")
	public List<Employee> reteriveAllEmployeeValues() {
			logger.info("Inside reteriveAllEmployeeValues method of EmployeeController");
	        return employeeService.reteriveAllEmployeeValues();
	}
	
    @GetMapping("/{id}")
	public ResponseVO findByEmployeeId(@PathVariable("id") Long employeeID) {
	     	logger.info("Inside findByEmployeeId method of EmployeeController");
	        return employeeService.findByEmployeeId(employeeID);
	}
   
   @GetMapping("/department/{id}")
   public ResponseVO findByDepartmentId(@PathVariable("id") Long departmentId) {
	   logger.info("Inside findByDepartmentId method of EmployeeController");
       return employeeService.findEmployeeByDepartmentId(departmentId);
   }
}
