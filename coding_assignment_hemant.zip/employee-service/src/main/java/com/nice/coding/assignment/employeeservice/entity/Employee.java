package com.nice.coding.assignment.employeeservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee") 
public class Employee {
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="employeeid")
	private Long employeeId;
	@Column(name="firstname")
	private String firstName;
	@Column(name="lastname")
	private String lastName;
	private Long age;
	private Long salary;
	@Column(name="contactno")
	private Long contactNo;
	private String gender;
	@Column(name="departmentid")
	private Long departmentId;
	
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Employee(Long employeeId, String firstName, String lastName, Long age, Long salary, Long contactNo,
			String gender, Long departmentId) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.salary = salary;
		this.contactNo = contactNo;
		this.gender = gender;
		this.departmentId = departmentId;
	}


	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Long getAge() {
		return age;
	}
	public void setAge(Long age) {
		this.age = age;
	}
	public Long getSalary() {
		return salary;
	}
	public void setSalary(Long salary) {
		this.salary = salary;
	}
	public Long getContactNo() {
		return contactNo;
	}
	public void setContactNo(Long contactNo) {
		this.contactNo = contactNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Long getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}


	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName + ", age="
				+ age + ", salary=" + salary + ", contactNo=" + contactNo + ", gender=" + gender + ", departmentId="
				+ departmentId + "]";
	}
	
	

}
