package com.nice.coding.assignment.employeeservice.proxy;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Table;


public class Department {
	private Long id;
	private String dname;
	private String description;
	private Long dhead;
	
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Department(Long id, String dname, String description, Long dhead) {
		super();
		this.id = id;
		this.dname = dname;
		this.description = description;
		this.dhead = dhead;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getDhead() {
		return dhead;
	}

	public void setDhead(Long dhead) {
		this.dhead = dhead;
	}


	@Override
	public String toString() {
		return "Department [id=" + id + ", dname=" + dname + ", description=" + description + ", dhead=" + dhead + "]";
	}
	
	
}
