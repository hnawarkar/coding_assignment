create database EMPLOYEE_DEPT_SERVICE;
use EMPLOYEE_DEPT_SERVICE;
create table employee(  
  employeeId    decimal(4,0),  
  firstName    varchar(10),  
  lastName    varchar(10),
  age      decimal(6,0),  
  salary      decimal(7,2),  
  contactNo     decimal(10,2),
  gender      varchar(5),    
  departmentId   decimal(2,0),  
  constraint pk_emp primary key (employeeId) 
)

create table department(  
  departmentId  decimal(2,0),  
  name      varchar(14),  
  description        varchar(13),
  depthead decimal(4,0),  
  constraint pk_dept primary key (departmentId)
)
  

ALTER TABLE department
ADD FOREIGN KEY (depthead) REFERENCES employee (employeeId);

ALTER TABLE employee
ADD FOREIGN KEY (departmentId) REFERENCES department (departmentId);
